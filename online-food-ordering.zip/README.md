# Online Food Ordering System 🍕
This is a basic full-stack food ordering app using:
- Frontend: HTML, CSS, JS
- Backend: Node.js, Express
- Database: MongoDB

## Run the App

### Backend
```bash
cd backend
npm install
node server.js
```

### Frontend
Open `frontend/index.html` in a browser.

## Features
- Place food orders
- Stores order in MongoDB